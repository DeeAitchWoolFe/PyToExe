import sys

print("Hello world")
print(f"Running with Python {sys.version}")
